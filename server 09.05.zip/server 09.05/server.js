//Define servidor

const express = require("express"); //Importa o Express

const server = express(); //Constroi o servidor

//Adiciona recurso (Que é o recurso "/") (Quando fizer um get no servidor (Abrir) essa função é executada)
server.get("/",(req, res) => {
    res.send("Server is running :D")//Decide como valida
} )

//Módulo que vai configurar o server
module.exports = server;

//req - requisição
//res - resposta